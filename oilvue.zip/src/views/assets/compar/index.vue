
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Compar'
}
</script>
