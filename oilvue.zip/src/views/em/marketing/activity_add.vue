
<template>
  <div>
    <!-- <p>activity_add</p> -->
    <p>开发中...</p>
  </div>
</template>

<script>
export default {
    name: 'ActivityAdd'
}
</script>
