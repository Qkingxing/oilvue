
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Elist'
}
</script>
