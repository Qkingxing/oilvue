
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Sale'
}
</script>
