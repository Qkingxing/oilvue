
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Retail'
}
</script>
