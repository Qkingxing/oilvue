<template>
  <div>
    sales
  </div>
</template>

<script>
export default {
  name: 'Sales'
}
</script>
