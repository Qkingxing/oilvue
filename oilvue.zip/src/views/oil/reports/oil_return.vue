
<template>
  <div>
    oil_return
  </div>
</template>

<script>
export default {
  name: 'OilReturn'
}
</script>
