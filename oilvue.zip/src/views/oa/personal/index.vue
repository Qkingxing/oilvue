
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Personal'
}
</script>
