
<template>
  <div>
    <div  showbreadcrumb="true" class="mainContainreBox">
      <div  class="mainContainreBlock">
      <div   class="container animated fadeIn">
          <a-tabs @change="tabChange" default-active-key="1" size="large">
            <a-tab-pane key="1" tab="油品支付">
              <a-radio-group class="tabs_list_wrap" @change="radioChange" default-value="1" size="large">
                <a-radio-button value="1">
                  客户联
                </a-radio-button>
                <a-radio-button value="2">
                  商户联
                </a-radio-button>
                <a-radio-button value="3">
                  客户补打联
                </a-radio-button>
              </a-radio-group>
          <div  class="flex_wrap">
            <div  class="ticket_wrap">
              <div   class="ticketBox">
                <img  src="./logo.png" class="logo">
                <span  class="station_name">能链集团加油站</span>
                <span  class="small_title">（客户联）</span>
                <div  class="text_wrap border_style" >
                  <span  >油站地址：深圳市南山区</span>
                  <span  >油站电话：88888888</span>
                </div>
     
    

    <div  class="text_wrap border_style oil_msg_wrap">
      <div >
        <div  class="oil_item"><span >油枪</span>
          <span >88</span>
        </div>
        <div  class="oil_item">
          <span >油号</span>
          <span >98#</span>
        </div>
        <div  class="oil_item">
          <span >数量</span>
          <span >88L</span>
        </div>
        <div  class="oil_item">
          <span >单价</span>
          <span >6.2元/升</span>
        </div>
        <div  class="oil_item" >
          <span >分割线</span>
        </div>
      </div>
    </div>
    
    <div  class="text_wrap border_style" >
      <div  class="pay_detail">
        <span  class="weight_style">应付金额：</span>
        <span  class="weight_style">¥100</span>
      </div>
      <div  class="pay_detail">
        <span>优惠：</span>
        <span>¥10</span>
      </div>
      <div  class="pay_detail">
        <span  class="weight_style">实付金额：</span>
        <span  class="weight_style">¥90</span>
      </div>
      <div  class="pay_detail">
        <span>
          微信支付：¥50<br>现金支付：¥40
        </span>
      </div>
      <div  class="pay_detail" >
        <span>分割线：</span>
      </div>
    </div>  
</div>
</div>
<div  class="ticket_setting_wrap">
    <div   class="ticketSetting">
      <div  class="header_wrap">
        <div  class="weight_tips"> 
        </div>
        <a-button type="link">
          恢复默认
        </a-button>
        </div>
        <div  class="list_wrap">
            <div  class="list_item">
              <div  class="item_left">
                <span>油站信息
                </span>
              </div>
              <div  class="item_right">
                <div  class="checkbox_group">
                    <div  class="extra_flex_style">
                    <a-checkbox-group
                      :options="station_info"
                     
                    >
                    </a-checkbox-group>
                    </div>
                  </div>
                </div>
                <div  class="operate_wrap">
                  <div  class="operate_item">↑</div>
                  <div  class="operate_item disabled_item">↓</div>
                </div>
            </div>
            <div  class="list_item">
              <div  class="item_left">
                <span>订单信息</span>
              </div>
              <div  class="item_right">
                <div  class="checkbox_group">
                 
                    <div  class="extra_flex_style">
                     <a-checkbox-group
                      :options="order_info"
                     
                    >
                     
                    </a-checkbox-group>
                    </div>
                  </div>
                </div>
                <div  class="operate_wrap">
                  <div  class="operate_item">↑</div>
                  <div  class="operate_item disabled_item">↓</div>
                </div>
            </div>
            <div  class="list_item">
              <div  class="item_left">
                <span>发票</span>
              </div>
              <div  class="item_right">
                <div  class="checkbox_group">
                 
                    <div  class="extra_flex_style">
                      <a-checkbox-group v-model="guanggaoChecked" :options="guanggaoOptions"  />
                    </div>
                  </div>
                </div>
                <div  class="operate_wrap">
                  <div  class="operate_item">↑</div>
                  <div  class="operate_item disabled_item">↓</div>
                </div>
            </div>
            <div  class="list_item">
              <div  class="item_left">
                <span>发票</span>
              </div>
              <div  class="item_right">
                <div  class="checkbox_group">
                 
                    <div  class="extra_flex_style">
                      <a-checkbox-group v-model="guanggaoChecked" :options="guanggaoOptions"  />
                    </div>
                  </div>
                </div>
                <div  class="operate_wrap">
                  <div  class="operate_item">↑</div>
                  <div  class="operate_item disabled_item">↓</div>
                </div>
            </div>
            <div  class="list_item">
              <div  class="item_left">
                <span>发票</span>
              </div>
              <div  class="item_right">
                <div  class="checkbox_group">
                 
                    <div  class="extra_flex_style">
                      <a-checkbox-group v-model="guanggaoChecked" :options="guanggaoOptions"  />
                    </div>
                  </div>
                </div>
                <div  class="operate_wrap">
                  <div  class="operate_item">↑</div>
                  <div  class="operate_item disabled_item">↓</div>
                </div>
            </div>
            <div  class="list_item">
              <div  class="item_left">
                <span>发票</span>
              </div>
              <div  class="item_right">
                <div  class="checkbox_group">
                 
                    <div  class="extra_flex_style">
                      <a-checkbox-group v-model="guanggaoChecked" :options="guanggaoOptions"  />
                    </div>
                  </div>
                </div>
                <div  class="operate_wrap">
                  <div  class="operate_item">↑</div>
                  <div  class="operate_item disabled_item">↓</div>
                </div>
            </div>
           <div  class="list_item">
              <div  class="item_left">
                <span>发票</span>
              </div>
              <div  class="item_right">
                <div  class="checkbox_group">
                 
                    <div  class="extra_flex_style">
                      <a-checkbox-group v-model="guanggaoChecked" :options="guanggaoOptions"  />
                    </div>
                  </div>
                </div>
                <div  class="operate_wrap">
                  <div  class="operate_item">↑</div>
                  <div  class="operate_item disabled_item">↓</div>
                </div>
            </div>
            <div  class="list_item">
              <div  class="item_left">
                <span>推广</span>
              </div>
              <div  class="item_right">
                <div  class="checkbox_group">
                  <div  class="extra_flex_style">
                    <a-checkbox class="select_item">
                      广告语
                    </a-checkbox>
                    <div  class="tips_setting_wrap">
                      <a-textarea class="tips_area" placeholder="欢迎关注公众号" :rows="4" />
                        <a-radio-group class="tips_radio_group" name="radioGroup" :default-value="1">
                          <a-radio :value="1">
                            靠左
                          </a-radio>
                          <a-radio :value="2">
                            居中
                          </a-radio>
                          <a-radio :value="3">
                            靠右
                          </a-radio>
                        </a-radio-group>
                      </div>
                    </div>
                    <div  class="extra_flex_style">
                      <a-checkbox-group v-model="guanggaoChecked" :options="guanggaoOptions"  />
                    </div>
                  </div>
                </div>
                <div  class="operate_wrap">
                  <div  class="operate_item">↑</div>
                  <div  class="operate_item disabled_item">↓</div>
                </div>
            </div>
               <div  class="list_item">
              <div  class="item_left">
                <span>小票提示</span>
              </div>
              <div  class="item_right">
                <div  class="checkbox_group">
                  <div  class="extra_flex_style">
                    <a-checkbox class="select_item">
                      提示语
                    </a-checkbox>
                    <div  class="tips_setting_wrap">
                      <a-textarea class="tips_area" placeholder="今天又吃成长快乐了！" :rows="4" />
                        <a-radio-group class="tips_radio_group" name="radioGroup" :default-value="1">
                          <a-radio :value="1">
                            靠左
                          </a-radio>
                          <a-radio :value="2">
                            居中
                          </a-radio>
                          <a-radio :value="3">
                            靠右
                          </a-radio>
                        </a-radio-group>
                      </div>
                    </div>
                    <div  class="extra_flex_style">
                      <a-checkbox>
                        分割线
                      </a-checkbox>
                    </div>
                  </div>
                </div>
                <div  class="operate_wrap">
                  <div  class="operate_item">↑</div>
                  <div  class="operate_item disabled_item">↓</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
            </a-tab-pane>
            <a-tab-pane key="2" tab="闪付小票">
              
            </a-tab-pane>
            <a-tab-pane key="3" tab="油品退款">
              
            </a-tab-pane>
            <a-tab-pane key="4" tab="闪付退款">
              
            </a-tab-pane>
            <a-tab-pane key="5" tab="加油卡开卡">
              
            </a-tab-pane>
            <a-tab-pane key="6" tab="加油卡充值">
              
            </a-tab-pane>
            <a-tab-pane key="7" tab="加油卡查询">
              
            </a-tab-pane>
            <a-tab-pane key="8" tab="充值退款">
              
            </a-tab-pane>
            <a-tab-pane key="9" tab="团油支付">
              
            </a-tab-pane>
            <a-tab-pane key="10" tab="便利店">
              
            </a-tab-pane>
            <a-tab-pane key="11" tab="便利店退款">
              
            </a-tab-pane>
            <a-tab-pane key="12" tab="商品核销">
              
            </a-tab-pane>
          </a-tabs>
      </div>
      <div  class="footer_wrap">
        <div  class="footer_box">
          <a-button type="primary">
            应用
          </a-button>
        </div>
      </div>
    </div>
  </div>
  </div>

</template>

<script>
import api from '../../../api/set.js'
export default {
    name: 'Receipts',
    data(){
      return{
        "user_info":[],
        "consumption_detail":[],
        "payment_info":[],
        "account_change":[],
        "receipt_info":[],
        "advertising":[],
        "receipt_notice":[],
        station_info:[],
        resData:[],
        radioType:1,
        type:1,

        order_info:[],
        guanggaoChecked:[],
        guanggaoOptions:['公众号二维码', '微信小程序二维码', '分割线']
      }
    },
    mounted(){
      this.setReceiptstylelist()
    },
    methods:{
      radioChange(type){
        this.radioType=type.target.value
      },
      tabChange(type){
        this.type=type
        this.setReceiptstylelist()
      },
      setReceiptstylelist(){
        let that=this
        api.setReceiptstylelist({
          type:that.type
        })
          .then(res => {
             console.log(res.data)
          }).catch(err=>{
            console.log(err)
          })
      }
    }
}
</script>
<style scoped>
.ticketBox .text_wrap .weight_style {
    font-weight: 500;
    font-size: 24px;
    margin: 10px 0;
}
.ticketBox .text_wrap .pay_detail {
  
    display: flex;
}
.ticketBox span{
    display: inline-block;
    color: #1e1e28;
}
.ticketBox .small_title {
    font-size: 18px;
    line-height: 24px;
    text-align: center;
    width: 100%;
    margin-bottom: 40px;
}
.ticketBox .station_name {
    text-align: center;
    font-weight: 500;
    color: #1e1e28;
    font-size: 24px;
    width: 100%;
}
.tabs_list_wrap {
    margin: 12px 0 0 82px;
}
  .flex_wrap {
      display: flex;
     
  }
  .footer_wrap {
    position: fixed;
    height: 80px;
    width: 100%;
    right: 0;
    box-sizing: border-box;
    padding-right: 28px;
    padding-left: 276px;
    bottom: 0;
}
.footer_wrap .footer_box {
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 -2px 8px 0 #e4e7f0;
    width: 100%;
    height: 100%;
    background: #fff;
}
.flex_wrap .ticket_wrap {
  margin-top: 24px;
  margin-left: 20px;
}
.flex_wrap .ticket_setting_wrap {
  margin-left: 36px;
}
.container {
    padding-bottom: 130px;
    background: #fff;
}
.ticketBox {
    position: relative;
    width: 360px;
    box-sizing: border-box;
    box-shadow: 0 4px 16px 0 rgba(0, 0, 0,.1);
    margin-left: 8px;
    background: #fff;
    background-size: 20px 10px;
    background-repeat: repeat-x;
    background-position: 0 100%;
    padding: 24px 24px 42px;
}
.ticketBox .logo {
    width: 40px;
    height: 40px;
    margin: 0 auto 16px;
    display: block;
}
.ticketBox .border_style {
  border-bottom: 2px dashed #3e4b6e;
}
.ticketBox .text_wrap {
    margin-bottom: 22px;
    padding-bottom: 22px;
    color: #1e1e28;
    font-size: 16px;
}
.ticketBox .text_wrap span {
    display: inline-block;
    word-break: break-all;
}
.ticketBox:after {
    position: absolute;
    content: "";
    bottom: -12px;
    left: 0;
    width: 100%;
    height: 12px;
    background: url(./wave.png);
}

.header_wrap {
   
    display: flex;
   
    align-items: center;
    width: 660px;
   
    justify-content: space-between;
    margin-top: -7px;
}
.list_wrap .list_item {
    background: #f5f5fa;
    width: 660px;
    padding: 27px 0 0;
    margin-bottom: 8px;
   
    display: flex;
    position: relative;
}
.list_wrap .list_item .item_left {
    width: 108px;
    text-align: right;
}
.list_wrap .list_item .item_right {
   
    display: flex;
    margin-left: 20px;
    width: 80%;
}
.list_wrap .list_item .item_left span {
    color: #1e1e28;
    font-weight: 500;
}
.list_wrap .list_item .item_right{
   
    display: flex;
    margin-left: 20px;
    width: 80%;
}
.list_wrap .list_item .item_right .checkbox_group {
    
    display: flex;
    flex-wrap: wrap;
}
.list_wrap .list_item .item_right .checkbox_group .extra_flex_style {
    display: flex;
    margin-bottom: 16px;
}
.list_wrap .list_item .item_right .select_item{
    width: 156px;
    margin: 0 0 10px 0;
}
.list_wrap .list_item .operate_wrap {
    position: absolute;
    top: 39px;
    right: -54px;
  
    display: flex;
}
.list_wrap .list_item .operate_wrap .disabled_item {
    color: #d8d8d8;
    border: 1px solid #d8d8d8;
    cursor: default;
}
.list_wrap .list_item .operate_wrap .operate_item {
    width: 16px;
    height: 16px;
    color: #3c3c46;
    border: 1px solid #666;
    border-radius: 50%;
    line-height: 14px;
    text-align: center;
    font-size: 12px;
    margin-right: 8px;
    cursor: pointer;
}
.list_wrap .list_item .operate_wrap .disabled_item {
    color: #d8d8d8;
    border: 1px solid #d8d8d8;
    cursor: default;
}
.tabs_list_wrap {
    margin: 12px 0 0 82px;
}

.list_wrap .list_item .item_right .tips_setting_wrap{
  display:flex;
}
.list_wrap .list_item .item_right .tips_setting_wrap .tips_radio_group {
    margin-top: -2px;
}

.list_wrap .list_item .item_right .tips_setting_wrap .tips_area{
    margin-left: -50px;
    width: 280px;
    height: 80px;
    margin-right: 8px;
    margin-bottom: 10px;
    margin-top: -5px;
}
.list_wrap .list_item .item_right .select_item {
    width: 156px;
    margin: 0 0 10px 0;
}
</style>
