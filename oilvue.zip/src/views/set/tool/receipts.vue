
<template>
  <div>
    receipts
  </div>
</template>

<script>
export default {
    name: 'Receipts'
}
</script>
