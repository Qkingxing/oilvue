
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Tool'
}
</script>
