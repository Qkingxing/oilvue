
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Notice'
}
</script>
