
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Commodity'
}
</script>
