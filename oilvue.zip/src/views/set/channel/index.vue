
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Channel'
}
</script>
