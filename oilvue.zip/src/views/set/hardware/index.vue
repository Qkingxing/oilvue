
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Hardware'
}
</script>
