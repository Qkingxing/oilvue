
<template>
  <div>
    help
  </div>
</template>

<script>
export default {
    name: 'Help'
}
</script>
