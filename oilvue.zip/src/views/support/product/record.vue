
<template>
  <div>
    record
  </div>
</template>

<script>
export default {
    name: 'Srecord'
}
</script>
