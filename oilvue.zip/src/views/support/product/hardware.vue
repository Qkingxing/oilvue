
<template>
  <div>
    hardware
  </div>
</template>

<script>
export default {
    name: 'Shardware'
}
</script>
