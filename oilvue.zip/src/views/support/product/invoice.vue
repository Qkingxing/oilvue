
<template>
  <div>
    invoice
  </div>
</template>

<script>
export default {
    name: 'SUinvoice'
}
</script>
