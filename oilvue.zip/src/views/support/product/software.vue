
<template>
  <div>
    software
  </div>
</template>

<script>
export default {
    name: 'Software'
}
</script>
