
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Product'
}
</script>
