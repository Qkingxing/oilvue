
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Cmember'
}
</script>
