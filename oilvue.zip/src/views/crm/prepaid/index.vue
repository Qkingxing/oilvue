
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Prepaid'
}
</script>
