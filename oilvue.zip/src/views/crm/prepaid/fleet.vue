
<template>
  <div>
    fleet
  </div>
</template>

<script>
export default {
    name: 'Fleet'
}
</script>
