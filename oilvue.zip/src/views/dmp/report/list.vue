
<template>
  <div>
    list
  </div>
</template>

<script>
export default {
    name: 'List'
}
</script>
