
<template>
  <router-view />
</template>

<script>
export default {
    name: 'Em'
}
</script>
