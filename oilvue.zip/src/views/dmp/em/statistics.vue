
<template>
  <div>statistics</div>
</template>

<script>
export default {
    name: 'Statistics'
}
</script>
