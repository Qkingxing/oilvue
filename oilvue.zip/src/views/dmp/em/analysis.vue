
<template>
  <div>analysis</div>
</template>

<script>
export default {
    name: 'Analysis'
}
</script>
