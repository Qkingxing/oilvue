export default {
  submit: 'Submit',
  save: 'Save',
  'submit.ok': 'Submit successfully',
  'save.ok': 'Saved successfully'
}
