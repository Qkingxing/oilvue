// 卡类型
var cardTypeList = [
    { label: '个人卡', value: 1 },
    { label: '车队卡', value: 2 },
]
// 优惠类型
var giveMoneyTypeList = [
    { label: '无优惠', value: 0 },
    { label: '立赠', value: 1 },
    { label: '立减', value: 2 },
    { label: '折扣', value: 3 },

]

export {
    cardTypeList,
    giveMoneyTypeList
}